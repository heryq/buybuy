package com.ezen.buybuy.entity;

public class AdminBanner {

}
