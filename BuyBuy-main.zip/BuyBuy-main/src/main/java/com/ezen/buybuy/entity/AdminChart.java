package com.ezen.buybuy.entity;
import lombok.Data;

@Data
public class AdminChart {
    private int total_quantity_0;
    private int total_quantity_1;
    private int total_quantity_2; 
    private int total_quantity_3;
    private int total_quantity_4;
    private int total_quantity_5;
    private int total_quantity_6;
    private int total_quantity_7;
    private int total_quantity_8; 
    private int total_quantity_9;
    private int total_quantity_10; 
    private int total_quantity_11;
    private int total_quantity_12;
    private int total_quantity_13; 
    private int total_quantity_14; 
    private int total_quantity_15; 
    private int total_quantity_16; 
    private int total_quantity_17; 
    private int total_quantity_18;
    private int total_quantity_19; 
    private int total_quantity_20; 
    private int total_quantity_21; 
    private int total_quantity_22;
    private int total_quantity_23;
}