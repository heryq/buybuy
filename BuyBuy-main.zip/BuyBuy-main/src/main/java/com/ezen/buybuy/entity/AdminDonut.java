package com.ezen.buybuy.entity;

import lombok.Data;

@Data
public class AdminDonut {
	private int kakao;
	private int google;
	private int naver;
	private int normal;
	
}
