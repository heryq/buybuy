package com.ezen.buybuy.entity;

import lombok.Data;

@Data
public class ApplyDealerACT {
	private String member_id;
	private int status;
}
