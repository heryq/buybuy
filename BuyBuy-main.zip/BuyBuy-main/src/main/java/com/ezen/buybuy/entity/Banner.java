package com.ezen.buybuy.entity;

import lombok.Data;

@Data
public class Banner {
	private String banner_name;
	private String image_url;
	private String banner_text;
	private String banner_url;
}
