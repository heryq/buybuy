package com.ezen.buybuy.entity;

import lombok.Data;

@Data
public class Categories {
	
	private int ctgr_idx;	
	private String ctgr_name;

}
