package com.ezen.buybuy.entity;

import lombok.Data;

@Data
public class MembersRq {
	 private String member_id;
	 private String account_status;

}
