select * from products;
select * from categories;
select * from orders;
select * from members;
 hoccoma                      1234                  BEOMHO PARK NULL     user           11952 서울특별시 서초구 1303-37 서초W타워 13층 123123     010-3255-8797 hoccoma@naver.com                                                                                                    2023-12-27 activate
update members set account_type = 'user' where member_id='aa'; 